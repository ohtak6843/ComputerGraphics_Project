#pragma once


struct BB {
	float left;
	float right;
	float top;
	float bottom;
	float front;
	float back;
};